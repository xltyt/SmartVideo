#include <pybind11/functional.h>
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

#include "tiktoken/bpe.h"
#include "tiktoken/core.h"

#include <unordered_set>
#include <vector>

namespace py = pybind11;

static tiktoken::Ranks py_dict_to_ranks(const py::dict &d) {
    tiktoken::Ranks ranks;
    for (auto item : d) {
        py::bytes key = item.first.cast<py::bytes>();
        char *ptr = nullptr;
        py::ssize_t size = 0;
        if (PYBIND11_BYTES_AS_STRING_AND_SIZE(key.ptr(), &ptr, &size)) {
            throw std::runtime_error("Failed to extract bytes");
        }
        std::vector<uint8_t> key_vec(ptr, ptr + size);
        std::size_t value = item.second.cast<std::size_t>();
        ranks[key_vec] = value;
    }
    return ranks;
}

static std::unordered_map<std::string, std::size_t>
py_dict_to_special_tokens(const py::dict &d) {
    std::unordered_map<std::string, std::size_t> result;
    for (auto item : d) {
        std::string key = item.first.cast<std::string>();
        std::size_t value = item.second.cast<std::size_t>();
        result[key] = value;
    }
    return result;
}

class PyCoreBPE {
  public:
    PyCoreBPE(const py::dict &encoder, const py::dict &special_tokens_encoder,
              const std::string &pattern)
        : core_bpe_(py_dict_to_ranks(encoder),
                     py_dict_to_special_tokens(special_tokens_encoder),
                     pattern) {}

    py::list encode_ordinary(const std::string &text) {
        auto tokens = core_bpe_.encode_ordinary(text);
        py::list result;
        for (std::size_t i = 0; i < tokens.size(); ++i) {
            result.append(tokens[i]);
        }
        return result;
    }

    py::list encode(const std::string &text, const std::unordered_set<std::string> &allowed_special) {
        auto tokens = core_bpe_.encode(text, allowed_special);
        py::list result;
        for (std::size_t i = 0; i < tokens.size(); ++i) {
            result.append(tokens[i]);
        }
        return result;
    }

    py::tuple encode_with_unstable(const std::string &text,
                                    const std::unordered_set<std::string> &allowed_special) {
        auto result_pair = core_bpe_.encode_with_unstable(text, allowed_special);

        py::list py_tokens;
        for (std::size_t i = 0; i < result_pair.first.size(); ++i) {
            py_tokens.append(result_pair.first[i]);
        }

        py::list py_completions;
        for (std::size_t i = 0; i < result_pair.second.size(); ++i) {
            py::list py_seq;
            for (std::size_t j = 0; j < result_pair.second[i].size(); ++j) {
                py_seq.append(result_pair.second[i][j]);
            }
            py_completions.append(py_seq);
        }

        return py::make_tuple(py_tokens, py_completions);
    }

    std::size_t encode_single_token(const py::bytes &piece) {
        char *ptr = nullptr;
        py::ssize_t size = 0;
        if (PYBIND11_BYTES_AS_STRING_AND_SIZE(piece.ptr(), &ptr, &size)) {
            throw std::runtime_error("Failed to extract bytes");
        }
        std::vector<uint8_t> vec(ptr, ptr + size);
        return core_bpe_.encode_single_token(vec);
    }

    py::list encode_single_piece(const py::bytes &piece) {
        char *ptr = nullptr;
        py::ssize_t size = 0;
        if (PYBIND11_BYTES_AS_STRING_AND_SIZE(piece.ptr(), &ptr, &size)) {
            throw std::runtime_error("Failed to extract bytes");
        }
        std::vector<uint8_t> vec(ptr, ptr + size);
        auto tokens = core_bpe_.encode_single_piece(vec);
        py::list result;
        for (std::size_t i = 0; i < tokens.size(); ++i) {
            result.append(tokens[i]);
        }
        return result;
    }

    py::bytes decode_bytes(const py::list &tokens) {
        std::vector<std::size_t> token_vec;
        token_vec.reserve(tokens.size());
        for (auto t : tokens) {
            token_vec.push_back(t.cast<std::size_t>());
        }
        auto bytes = core_bpe_.decode_bytes(token_vec);
        return py::bytes(reinterpret_cast<const char *>(bytes.data()), bytes.size());
    }

    py::bytes decode_single_token_bytes(std::size_t token) {
        auto bytes = core_bpe_.decode_single_token_bytes(token);
        return py::bytes(reinterpret_cast<const char *>(bytes.data()), bytes.size());
    }

    py::list token_byte_values() {
        auto values = core_bpe_.token_byte_values();
        py::list result;
        for (std::size_t i = 0; i < values.size(); ++i) {
            result.append(py::bytes(reinterpret_cast<const char *>(values[i].data()), values[i].size()));
        }
        return result;
    }

    py::list _encode_bytes(const py::bytes &bytes_arg) {
        char *ptr = nullptr;
        py::ssize_t size = 0;
        if (PYBIND11_BYTES_AS_STRING_AND_SIZE(bytes_arg.ptr(), &ptr, &size)) {
            throw std::runtime_error("Failed to extract bytes");
        }
        std::vector<uint8_t> vec(ptr, ptr + size);
        auto tokens = core_bpe_.encode_bytes(vec);
        py::list result;
        for (std::size_t i = 0; i < tokens.size(); ++i) {
            result.append(tokens[i]);
        }
        return result;
    }

  private:
    tiktoken::CoreBPE core_bpe_;
};

PYBIND11_MODULE(_tiktoken, m) {
    m.doc() = "C++ implementation of tiktoken CoreBPE";

    py::class_<PyCoreBPE>(m, "CoreBPE")
        .def(py::init<const py::dict &, const py::dict &, const std::string &>(),
             py::arg("encoder"),
             py::arg("special_tokens_encoder"),
             py::arg("pattern"))
        .def("encode_ordinary", &PyCoreBPE::encode_ordinary,
             py::arg("text"))
        .def("encode", &PyCoreBPE::encode,
             py::arg("text"), py::arg("allowed_special"))
        .def("encode_with_unstable", &PyCoreBPE::encode_with_unstable,
             py::arg("text"), py::arg("allowed_special"))
        .def("encode_single_token", &PyCoreBPE::encode_single_token,
             py::arg("piece"))
        .def("encode_single_piece", &PyCoreBPE::encode_single_piece,
             py::arg("piece"))
        .def("decode_bytes", &PyCoreBPE::decode_bytes,
             py::arg("tokens"))
        .def("decode_single_token_bytes", &PyCoreBPE::decode_single_token_bytes,
             py::arg("token"))
        .def("token_byte_values", &PyCoreBPE::token_byte_values)
        .def("_encode_bytes", &PyCoreBPE::_encode_bytes,
             py::arg("bytes"));
}
