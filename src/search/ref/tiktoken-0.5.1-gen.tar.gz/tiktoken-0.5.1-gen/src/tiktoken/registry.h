#pragma once

#include <cstdint>
#include <functional>
#include <mutex>
#include <string>
#include <vector>

namespace tiktoken {

class Encoding;

// Factory function type for creating an Encoding
using EncodingConstructor = std::function<Encoding()>;

// Get encoding by name
Encoding get_encoding(const std::string &encoding_name);

// List available encoding names
std::vector<std::string> list_encoding_names();

} // namespace tiktoken
