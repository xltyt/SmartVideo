#pragma once

#include <string>

namespace tiktoken {

class Encoding;

std::string encoding_name_for_model(const std::string &model_name);
Encoding encoding_for_model(const std::string &model_name);

} // namespace tiktoken
