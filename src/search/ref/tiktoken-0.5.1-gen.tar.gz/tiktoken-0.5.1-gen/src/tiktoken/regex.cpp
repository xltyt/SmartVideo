#include "regex.h"

#define PCRE2_CODE_UNIT_WIDTH 8
#include <pcre2.h>

#include <cstring>

namespace tiktoken {

Regex::Regex() = default;

Regex::Regex(const std::string &pattern) : pattern_(pattern) {
    int errcode;
    PCRE2_SIZE erroffset;
    re_ = pcre2_compile(
        reinterpret_cast<PCRE2_SPTR8>(pattern.c_str()),
        PCRE2_ZERO_TERMINATED,
        PCRE2_UCP | PCRE2_UTF,
        &errcode, &erroffset, nullptr);
}

Regex::Regex(const Regex &other) : pattern_(other.pattern_) {
    if (other.re_) {
        re_ = pcre2_code_copy(reinterpret_cast<pcre2_code_8 *>(other.re_));
    }
}

Regex::Regex(Regex &&other) noexcept : re_(other.re_), pattern_(std::move(other.pattern_)) {
    other.re_ = nullptr;
}

Regex &Regex::operator=(const Regex &other) {
    if (this != &other) {
        if (re_) {
            pcre2_code_free(reinterpret_cast<pcre2_code_8 *>(re_));
        }
        pattern_ = other.pattern_;
        if (other.re_) {
            re_ = pcre2_code_copy(reinterpret_cast<pcre2_code_8 *>(other.re_));
        } else {
            re_ = nullptr;
        }
    }
    return *this;
}

Regex &Regex::operator=(Regex &&other) noexcept {
    if (this != &other) {
        if (re_) {
            pcre2_code_free(reinterpret_cast<pcre2_code_8 *>(re_));
        }
        re_ = other.re_;
        pattern_ = std::move(other.pattern_);
        other.re_ = nullptr;
    }
    return *this;
}

Regex::~Regex() {
    if (re_) {
        pcre2_code_free(reinterpret_cast<pcre2_code_8 *>(re_));
    }
}

std::vector<Regex::Match> Regex::find_iter(const std::string &text) const {
    std::vector<Match> result;
    if (!re_) {
        return result;
    }

    pcre2_match_data_8 *match_data =
        pcre2_match_data_create_from_pattern(reinterpret_cast<pcre2_code_8 *>(re_), nullptr);
    if (!match_data) {
        return result;
    }

    PCRE2_SIZE start_offset = 0;
    while (start_offset <= text.size()) {
        int rc = pcre2_match(
            reinterpret_cast<pcre2_code_8 *>(re_),
            reinterpret_cast<PCRE2_SPTR8>(text.c_str()),
            static_cast<PCRE2_SIZE>(text.size()),
            start_offset,
            0,
            match_data,
            nullptr);

        if (rc < 0) {
            break;
        }

        PCRE2_SIZE *ovector = pcre2_get_ovector_pointer(match_data);
        Match m;
        m.start = ovector[0];
        m.end = ovector[1];
        m.str = text.substr(m.start, m.end - m.start);

        if (m.end == m.start) {
            start_offset = m.end + 1;
        } else {
            start_offset = m.end;
        }

        result.push_back(std::move(m));
    }

    pcre2_match_data_free(match_data);
    return result;
}

bool Regex::find_from_pos(const std::string &text, std::size_t start,
                          Match &out) const {
    if (!re_ || start > text.size()) {
        return false;
    }

    pcre2_match_data_8 *match_data =
        pcre2_match_data_create_from_pattern(reinterpret_cast<pcre2_code_8 *>(re_), nullptr);
    if (!match_data) {
        return false;
    }

    int rc = pcre2_match(
        reinterpret_cast<pcre2_code_8 *>(re_),
        reinterpret_cast<PCRE2_SPTR8>(text.c_str()),
        static_cast<PCRE2_SIZE>(text.size()),
        static_cast<PCRE2_SIZE>(start),
        0,
        match_data,
        nullptr);

    if (rc < 0) {
        pcre2_match_data_free(match_data);
        return false;
    }

    PCRE2_SIZE *ovector = pcre2_get_ovector_pointer(match_data);
    out.start = ovector[0];
    out.end = ovector[1];
    out.str = text.substr(out.start, out.end - out.start);

    pcre2_match_data_free(match_data);
    return true;
}

std::string Regex::escape(const std::string &s) {
    std::string result;
    result.reserve(s.size() * 2);

    for (char c : s) {
        if (c == '\\' || c == '.' || c == '^' || c == '$' || c == '|' ||
            c == '(' || c == ')' || c == '[' || c == ']' || c == '{' ||
            c == '}' || c == '*' || c == '+' || c == '?' || c == '-') {
            result += '\\';
        }
        result += c;
    }
    return result;
}

} // namespace tiktoken
