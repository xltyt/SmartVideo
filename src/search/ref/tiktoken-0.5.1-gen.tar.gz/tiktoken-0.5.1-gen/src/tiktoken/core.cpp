#include "core.h"
#include "bstr.h"

#include <algorithm>
#include <cassert>
#include <set>
#include <vector>

namespace tiktoken {

namespace {
    struct VecSizeHash {
        std::size_t operator()(const std::vector<std::size_t> &v) const noexcept {
            std::size_t h = 0x811c9dc5;
            for (std::size_t i = 0; i < v.size(); ++i) {
                h ^= v[i];
                h *= 0x01000193;
            }
            return h;
        }
    };

    bool token_is_all_space(std::size_t token,
                            const std::unordered_map<std::size_t, std::vector<uint8_t>> &decoder) {
        auto it = decoder.find(token);
        if (it == decoder.end()) return false;
        const auto &bytes = it->second;
        for (std::size_t i = 0; i < bytes.size(); ++i) {
            if (bytes[i] != ' ' && bytes[i] != '\n' && bytes[i] != '\t') return false;
        }
        return true;
    }

    std::size_t validate_utf8(const std::string &text) {
        std::size_t i = 0;
        while (i < text.size()) {
            unsigned char c = static_cast<unsigned char>(text[i]);
            std::size_t byte_count;

            if ((c & 0x80) == 0) {
                byte_count = 1;
            } else if ((c & 0xE0) == 0xC0) {
                byte_count = 2;
            } else if ((c & 0xF0) == 0xE0) {
                byte_count = 3;
            } else if ((c & 0xF8) == 0xF0) {
                byte_count = 4;
            } else {
                return i;
            }

            if (i + byte_count > text.size()) {
                return i;
            }

            for (std::size_t j = 1; j < byte_count; ++j) {
                if ((static_cast<unsigned char>(text[i + j]) & 0xC0) != 0x80) {
                    return i;
                }
            }

            i += byte_count;
        }
        return text.size();
    }

    bool is_whitespace(uint32_t cp) {
        return cp == ' ' || cp == '\n' || cp == '\t' || cp == '\r' ||
               cp == '\f' || cp == '\v' ||
               (cp >= 0x2000 && cp <= 0x200A) || cp == 0x2028 || cp == 0x2029 ||
               cp == 0x202F || cp == 0x205F || cp == 0x3000;
    }
} // namespace

CoreBPE::CoreBPE(const Ranks &encoder,
                 const std::unordered_map<std::string, std::size_t> &special_tokens_encoder,
                 const std::string &pattern)
    : encoder_(encoder), special_tokens_encoder_(special_tokens_encoder),
      regex_(pattern) {
    for (auto it = encoder_.begin(); it != encoder_.end(); ++it) {
        decoder_[it->second] = it->first;
    }

    for (auto it = special_tokens_encoder_.begin(); it != special_tokens_encoder_.end(); ++it) {
        special_tokens_decoder_[it->second] =
            std::vector<uint8_t>(it->first.begin(), it->first.end());
    }

    if (!regex_.is_valid()) {
        throw std::invalid_argument("Invalid regex pattern: " + pattern);
    }

    if (!special_tokens_encoder_.empty()) {
        std::vector<std::string> escaped_tokens;
        for (auto it = special_tokens_encoder_.begin(); it != special_tokens_encoder_.end(); ++it) {
            escaped_tokens.push_back(Regex::escape(it->first));
        }
        std::string special_pattern = "(" + escaped_tokens[0];
        for (std::size_t i = 1; i < escaped_tokens.size(); ++i) {
            special_pattern += "|" + escaped_tokens[i];
        }
        special_pattern += ")";
        special_regex_ = Regex(special_pattern);
        if (!special_regex_.is_valid()) {
            throw std::invalid_argument("Failed to compile special token regex");
        }
    }

    for (auto it = encoder_.begin(); it != encoder_.end(); ++it) {
        sorted_token_bytes_.push_back(it->first);
    }
    std::sort(sorted_token_bytes_.begin(), sorted_token_bytes_.end());
}

std::vector<std::size_t> CoreBPE::encode_ordinary(const std::string &text) const {
    return _encode_ordinary_native(text);
}

std::vector<std::size_t> CoreBPE::encode(const std::string &text,
                                         const std::unordered_set<std::string> &allowed_special) const {
    return _encode_native(text, allowed_special).first;
}

std::vector<std::size_t> CoreBPE::_encode_ordinary_native(const std::string &text) const {
    std::vector<std::size_t> result;
    auto matches = regex_.find_iter(text);

    for (std::size_t mi = 0; mi < matches.size(); ++mi) {
        const auto &mat = matches[mi];
        std::vector<uint8_t> piece(mat.str.begin(), mat.str.end());
        auto it = encoder_.find(piece);
        if (it != encoder_.end()) {
            result.push_back(it->second);
        } else {
            auto tokens = byte_pair_encode(piece, encoder_);
            result.insert(result.end(), tokens.begin(), tokens.end());
        }
    }

    return result;
}

std::pair<std::vector<std::size_t>, std::size_t>
CoreBPE::_encode_native(const std::string &text,
                        const std::unordered_set<std::string> &allowed_special) const {
    std::vector<std::size_t> result;
    std::size_t start = 0;
    std::size_t last_piece_token_len = 0;

    while (true) {
        Regex::Match next_special_match;
        bool found_special = false;
        std::size_t start_find = start;

        while (true) {
            Regex::Match m;
            if (!special_regex_.find_from_pos(text, start_find, m)) {
                break;
            }
            if (allowed_special.find(m.str) != allowed_special.end()) {
                next_special_match = m;
                found_special = true;
                break;
            }
            start_find = m.start + 1;
        }

        std::size_t end = found_special ? next_special_match.start : text.size();

        if (end > start) {
            std::string segment = text.substr(start, end - start);
            auto segment_matches = regex_.find_iter(segment);

            for (std::size_t mi = 0; mi < segment_matches.size(); ++mi) {
                const auto &mat = segment_matches[mi];
                std::vector<uint8_t> piece(mat.str.begin(), mat.str.end());
                auto it = encoder_.find(piece);
                if (it != encoder_.end()) {
                    last_piece_token_len = 1;
                    result.push_back(it->second);
                } else {
                    auto tokens = byte_pair_encode(piece, encoder_);
                    last_piece_token_len = tokens.size();
                    result.insert(result.end(), tokens.begin(), tokens.end());
                }
            }
        }

        if (found_special) {
            auto its = special_tokens_encoder_.find(next_special_match.str);
            if (its == special_tokens_encoder_.end()) {
                throw std::runtime_error("Special token not found: " + next_special_match.str);
            }
            result.push_back(its->second);
            start = next_special_match.end;
            last_piece_token_len = 0;
        } else {
            break;
        }
    }

    return std::make_pair(result, last_piece_token_len);
}

std::pair<std::vector<std::size_t>, std::size_t>
CoreBPE::_increase_last_piece_token_len(std::vector<std::size_t> tokens,
                                        std::size_t last_piece_token_len) const {
    if (last_piece_token_len > 0 && !tokens.empty() &&
        token_is_all_space(tokens[tokens.size() - last_piece_token_len], decoder_)) {
        while (last_piece_token_len < tokens.size() &&
               token_is_all_space(tokens[tokens.size() - last_piece_token_len - 1], decoder_)) {
            last_piece_token_len++;
        }
    }
    return std::make_pair(tokens, last_piece_token_len);
}

std::pair<std::vector<std::size_t>, std::vector<std::vector<std::size_t>>>
CoreBPE::encode_with_unstable(const std::string &text,
                              const std::unordered_set<std::string> &allowed_special) const {
    auto encode_result = _encode_native(text, allowed_special);
    std::vector<std::size_t> tokens = encode_result.first;
    std::size_t last_piece_token_len = encode_result.second;

    if (last_piece_token_len == 0) {
        return std::make_pair(tokens, std::vector<std::vector<std::size_t>>());
    }

    auto inc_result = _increase_last_piece_token_len(tokens, last_piece_token_len);
    tokens = inc_result.first;
    last_piece_token_len = inc_result.second;

    std::vector<std::size_t> unstable_tokens(
        tokens.end() - static_cast<std::ptrdiff_t>(last_piece_token_len), tokens.end());
    std::vector<uint8_t> unstable_bytes = _decode_native(unstable_tokens);
    tokens.resize(tokens.size() - last_piece_token_len);

    std::set<std::vector<std::size_t>> completions;

    if (unstable_bytes.empty()) {
        return std::make_pair(tokens, std::vector<std::vector<std::size_t>>(
            completions.begin(), completions.end()));
    }

    // Find all tokens that start with unstable_bytes
    auto point = std::partition_point(
        sorted_token_bytes_.begin(), sorted_token_bytes_.end(),
        [&unstable_bytes](const std::vector<uint8_t> &x) {
            return std::lexicographical_compare(
                x.begin(), x.end(), unstable_bytes.begin(), unstable_bytes.end());
        });

    std::size_t point_idx = static_cast<std::size_t>(point - sorted_token_bytes_.begin());
    while (point_idx < sorted_token_bytes_.size() &&
           sorted_token_bytes_[point_idx].size() >= unstable_bytes.size() &&
           std::equal(unstable_bytes.begin(), unstable_bytes.end(),
                      sorted_token_bytes_[point_idx].begin())) {
        auto it = encoder_.find(sorted_token_bytes_[point_idx]);
        if (it != encoder_.end()) {
            completions.insert({it->second});
        }
        ++point_idx;
    }

    // Try straddling tokens
    for (std::size_t i = 1; i < unstable_bytes.size(); ++i) {
        std::vector<uint8_t> prefix(unstable_bytes.begin(), unstable_bytes.begin() + i);
        std::vector<uint8_t> suffix(unstable_bytes.begin() + i, unstable_bytes.end());

        auto point2 = std::partition_point(
            sorted_token_bytes_.begin(), sorted_token_bytes_.end(),
            [&suffix](const std::vector<uint8_t> &x) {
                return std::lexicographical_compare(
                    x.begin(), x.end(), suffix.begin(), suffix.end());
            });

        std::size_t point2_idx = static_cast<std::size_t>(point2 - sorted_token_bytes_.begin());
        while (point2_idx < sorted_token_bytes_.size() &&
               sorted_token_bytes_[point2_idx].size() >= suffix.size() &&
               std::equal(suffix.begin(), suffix.end(),
                          sorted_token_bytes_[point2_idx].begin())) {
            std::vector<uint8_t> possibility = prefix;
            possibility.insert(possibility.end(),
                               sorted_token_bytes_[point2_idx].begin(),
                               sorted_token_bytes_[point2_idx].end());

            std::string poss_str(reinterpret_cast<const char *>(possibility.data()),
                                 possibility.size());
            std::size_t valid_len = validate_utf8(poss_str);

            std::vector<std::size_t> encoded;
            if (valid_len == possibility.size()) {
                encoded = _encode_ordinary_native(poss_str);
            } else {
                encoded = byte_pair_encode(possibility, encoder_);
            }

            std::vector<std::size_t> seq;
            std::size_t seq_len = 0;
            for (std::size_t j = 0; j < encoded.size(); ++j) {
                seq.push_back(encoded[j]);
                auto dit = decoder_.find(encoded[j]);
                if (dit != decoder_.end()) {
                    seq_len += dit->second.size();
                }
                if (seq_len >= unstable_bytes.size()) {
                    break;
                }
            }
            completions.insert(seq);
            ++point2_idx;
        }
    }

    // Handle unstable regex splits due to whitespace
    if (unstable_bytes.size() > 1) {
        auto last_utf8 = bstr::decode_last_utf8(unstable_bytes);
        uint32_t last_char_val = last_utf8.first;
        std::size_t consumed = last_utf8.second.first;
        bool valid = last_utf8.second.second;
        if (unstable_bytes.size() > consumed && valid && is_whitespace(last_char_val)) {
            std::vector<uint8_t> prefix2(unstable_bytes.begin(),
                                         unstable_bytes.begin() + unstable_bytes.size() - consumed);
            std::vector<uint8_t> suffix2(unstable_bytes.begin() + unstable_bytes.size() - consumed,
                                         unstable_bytes.end());

            auto encoded_prefix = byte_pair_encode(prefix2, encoder_);
            auto encoded_suffix = byte_pair_encode(suffix2, encoder_);
            std::vector<std::size_t> reencoded = encoded_prefix;
            reencoded.insert(reencoded.end(), encoded_suffix.begin(), encoded_suffix.end());
            completions.insert(reencoded);
        }
    }

    return std::make_pair(tokens, std::vector<std::vector<std::size_t>>(
        completions.begin(), completions.end()));
}

std::size_t CoreBPE::encode_single_token(const std::vector<uint8_t> &piece) const {
    auto it = encoder_.find(piece);
    if (it != encoder_.end()) {
        return it->second;
    }

    std::string token_str(piece.begin(), piece.end());
    auto its = special_tokens_encoder_.find(token_str);
    if (its != special_tokens_encoder_.end()) {
        return its->second;
    }

    throw std::runtime_error("Token not found in vocabulary");
}

std::vector<std::size_t> CoreBPE::encode_single_piece(const std::vector<uint8_t> &piece) const {
    auto it = encoder_.find(piece);
    if (it != encoder_.end()) {
        return {it->second};
    }
    return byte_pair_encode(piece, encoder_);
}

std::vector<std::size_t> CoreBPE::encode_bytes(const std::vector<uint8_t> &bytes) const {
    std::string text(reinterpret_cast<const char *>(bytes.data()), bytes.size());
    std::size_t valid_len = validate_utf8(text);

    if (valid_len == bytes.size()) {
        return _encode_ordinary_native(text);
    }

    std::string valid_text = text.substr(0, valid_len);
    auto encode_result = _encode_native(valid_text, std::unordered_set<std::string>());
    std::vector<std::size_t> tokens = encode_result.first;
    std::size_t last_piece_token_len = encode_result.second;

    auto inc_result = _increase_last_piece_token_len(tokens, last_piece_token_len);
    tokens = inc_result.first;
    last_piece_token_len = inc_result.second;

    if (!tokens.empty() && last_piece_token_len > 0) {
        std::vector<std::size_t> unstable_tokens(
            tokens.end() - static_cast<std::ptrdiff_t>(last_piece_token_len), tokens.end());
        std::vector<uint8_t> unstable_bytes = _decode_native(unstable_tokens);
        unstable_bytes.insert(unstable_bytes.end(),
                              bytes.begin() + static_cast<std::ptrdiff_t>(valid_len), bytes.end());

        tokens.resize(tokens.size() - last_piece_token_len);
        auto bpe_tokens = byte_pair_encode(unstable_bytes, encoder_);
        tokens.insert(tokens.end(), bpe_tokens.begin(), bpe_tokens.end());
    }

    return tokens;
}

std::vector<uint8_t> CoreBPE::decode_bytes(const std::vector<std::size_t> &tokens) const {
    return _decode_native(tokens);
}

std::vector<uint8_t> CoreBPE::_decode_native(const std::vector<std::size_t> &tokens) const {
    std::vector<uint8_t> result;
    result.reserve(tokens.size() * 2);

    for (std::size_t i = 0; i < tokens.size(); ++i) {
        auto it = decoder_.find(tokens[i]);
        if (it != decoder_.end()) {
            result.insert(result.end(), it->second.begin(), it->second.end());
        } else {
            auto its = special_tokens_decoder_.find(tokens[i]);
            if (its != special_tokens_decoder_.end()) {
                result.insert(result.end(), its->second.begin(), its->second.end());
            } else {
                throw std::runtime_error("Decode: token not found: " + std::to_string(tokens[i]));
            }
        }
    }

    return result;
}

std::vector<uint8_t>
CoreBPE::decode_single_token_bytes(std::size_t token) const {
    auto it = decoder_.find(token);
    if (it != decoder_.end()) {
        return it->second;
    }
    auto its = special_tokens_decoder_.find(token);
    if (its != special_tokens_decoder_.end()) {
        return its->second;
    }
    throw std::runtime_error("Token not found");
}

std::vector<std::vector<uint8_t>>
CoreBPE::token_byte_values() const {
    return sorted_token_bytes_;
}

} // namespace tiktoken
