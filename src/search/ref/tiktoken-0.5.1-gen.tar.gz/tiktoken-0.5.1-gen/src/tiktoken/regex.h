#pragma once

#include <string>
#include <vector>

namespace tiktoken {

// PCRE2-based regex wrapper supporting Unicode properties (\p{L}, \p{N}, etc.)
class Regex {
  public:
    Regex();
    explicit Regex(const std::string &pattern);
    Regex(const Regex &other);
    Regex(Regex &&other) noexcept;
    Regex &operator=(const Regex &other);
    Regex &operator=(Regex &&other) noexcept;
    ~Regex();

    struct Match {
        std::size_t start;
        std::size_t end;
        std::string str;
    };

    std::vector<Match> find_iter(const std::string &text) const;

    // Find next match from position. Returns empty optional if no match.
    // Uses PCRE2's pcre2_match starting from given offset.
    bool find_from_pos(const std::string &text, std::size_t start,
                       Match &out) const;

    static std::string escape(const std::string &s);

    bool is_valid() const { return re_ != nullptr; }

  private:
    void *re_ = nullptr; // pcre2_code_8*
    std::string pattern_;
};

} // namespace tiktoken
