#include "model.h"
#include "registry.h"
#include "tiktoken.h"

#include <stdexcept>
#include <string>
#include <vector>

namespace tiktoken {

namespace {

const std::vector<std::pair<std::string, std::string>> MODEL_PREFIX_TO_ENCODING = {
    {"gpt-4-", "cl100k_base"},
    {"gpt-3.5-turbo-", "cl100k_base"},
    {"gpt-35-turbo-", "cl100k_base"},
    {"ft:gpt-4", "cl100k_base"},
    {"ft:gpt-3.5-turbo", "cl100k_base"},
    {"ft:davinci-002", "cl100k_base"},
    {"ft:babbage-002", "cl100k_base"},
};

const std::vector<std::pair<std::string, std::string>> MODEL_TO_ENCODING = {
    {"gpt-4", "cl100k_base"},
    {"gpt-3.5-turbo", "cl100k_base"},
    {"gpt-35-turbo", "cl100k_base"},
    {"davinci-002", "cl100k_base"},
    {"babbage-002", "cl100k_base"},
    {"text-embedding-ada-002", "cl100k_base"},
    {"text-davinci-003", "p50k_base"},
    {"text-davinci-002", "p50k_base"},
    {"text-davinci-001", "r50k_base"},
    {"text-curie-001", "r50k_base"},
    {"text-babbage-001", "r50k_base"},
    {"text-ada-001", "r50k_base"},
    {"davinci", "r50k_base"},
    {"curie", "r50k_base"},
    {"babbage", "r50k_base"},
    {"ada", "r50k_base"},
    {"code-davinci-002", "p50k_base"},
    {"code-davinci-001", "p50k_base"},
    {"code-cushman-002", "p50k_base"},
    {"code-cushman-001", "p50k_base"},
    {"davinci-codex", "p50k_base"},
    {"cushman-codex", "p50k_base"},
    {"text-davinci-edit-001", "p50k_edit"},
    {"code-davinci-edit-001", "p50k_edit"},
    {"text-similarity-davinci-001", "r50k_base"},
    {"text-similarity-curie-001", "r50k_base"},
    {"text-similarity-babbage-001", "r50k_base"},
    {"text-similarity-ada-001", "r50k_base"},
    {"text-search-davinci-doc-001", "r50k_base"},
    {"text-search-curie-doc-001", "r50k_base"},
    {"text-search-babbage-doc-001", "r50k_base"},
    {"text-search-ada-doc-001", "r50k_base"},
    {"code-search-babbage-code-001", "r50k_base"},
    {"code-search-ada-code-001", "r50k_base"},
    {"gpt2", "gpt2"},
};

} // namespace

std::string encoding_name_for_model(const std::string &model_name) {
    for (std::size_t i = 0; i < MODEL_TO_ENCODING.size(); ++i) {
        if (model_name == MODEL_TO_ENCODING[i].first) {
            return MODEL_TO_ENCODING[i].second;
        }
    }

    for (std::size_t i = 0; i < MODEL_PREFIX_TO_ENCODING.size(); ++i) {
        if (model_name.compare(0, MODEL_PREFIX_TO_ENCODING[i].first.size(),
                              MODEL_PREFIX_TO_ENCODING[i].first) == 0) {
            return MODEL_PREFIX_TO_ENCODING[i].second;
        }
    }

    throw std::runtime_error(
        "Could not automatically map " + model_name +
        " to a tokeniser. Please use tiktoken::get_encoding to explicitly "
        "get the tokeniser you expect.");
}

Encoding encoding_for_model(const std::string &model_name) {
    return get_encoding(encoding_name_for_model(model_name));
}

} // namespace tiktoken
