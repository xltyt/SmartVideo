#pragma once

#include <cstdint>
#include <vector>

namespace tiktoken {
namespace bstr {

// Decode the last UTF-8 codepoint from a byte sequence.
// Returns (codepoint, number of bytes consumed from the end, is_valid).
// If invalid, returns (0, 1, false).
inline std::pair<uint32_t, std::pair<std::size_t, bool>>
decode_last_utf8(const std::vector<uint8_t> &data) {
    if (data.empty()) {
        return {0, {0, false}};
    }

    // Find the start of the last codepoint by scanning backward
    std::size_t i = data.size() - 1;
    while (i > 0 && (data[i] & 0xC0) == 0x80) {
        --i;
    }

    std::size_t consumed = data.size() - i;
    uint8_t b0 = data[i];

    // Determine byte count from leading byte
    std::size_t byte_count;
    if ((b0 & 0x80) == 0) {
        byte_count = 1;
    } else if ((b0 & 0xE0) == 0xC0) {
        byte_count = 2;
    } else if ((b0 & 0xF0) == 0xE0) {
        byte_count = 3;
    } else if ((b0 & 0xF8) == 0xF0) {
        byte_count = 4;
    } else {
        return {0, {1, false}};
    }

    if (consumed != byte_count) {
        return {0, {consumed, false}};
    }

    // Decode the codepoint
    uint32_t cp = 0;
    if (byte_count == 1) {
        cp = b0;
    } else if (byte_count == 2) {
        cp = (static_cast<uint32_t>(b0 & 0x1F) << 6) |
             (static_cast<uint32_t>(data[i + 1] & 0x3F));
    } else if (byte_count == 3) {
        cp = (static_cast<uint32_t>(b0 & 0x0F) << 12) |
             (static_cast<uint32_t>(data[i + 1] & 0x3F) << 6) |
             (static_cast<uint32_t>(data[i + 2] & 0x3F));
    } else if (byte_count == 4) {
        cp = (static_cast<uint32_t>(b0 & 0x07) << 18) |
             (static_cast<uint32_t>(data[i + 1] & 0x3F) << 12) |
             (static_cast<uint32_t>(data[i + 2] & 0x3F) << 6) |
             (static_cast<uint32_t>(data[i + 3] & 0x3F));
    }

    return {cp, {consumed, true}};
}

} // namespace bstr
} // namespace tiktoken
