#pragma once

#include "bpe.h"
#include "core.h"

#include <cstdint>
#include <exception>
#include <future>
#include <memory>
#include <mutex>
#include <sstream>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <vector>

namespace tiktoken {

class Encoding {
  public:
    // Default constructor for use with unordered_map
    Encoding() : name_(""), max_token_value_(0), explicit_n_vocab_(0) {}

    Encoding(const std::string &name,
             const std::string &pat_str,
             const Ranks &mergeable_ranks,
             const std::unordered_map<std::string, std::size_t> &special_tokens,
             std::size_t explicit_n_vocab = 0)
        : name_(name), pat_str_(pat_str),
          mergeable_ranks_(mergeable_ranks), special_tokens_(special_tokens),
          explicit_n_vocab_(explicit_n_vocab) {

        max_token_value_ = 0;
        for (auto it = mergeable_ranks.begin(); it != mergeable_ranks.end(); ++it) {
            if (it->second > max_token_value_) max_token_value_ = it->second;
        }
        for (auto it = special_tokens.begin(); it != special_tokens.end(); ++it) {
            if (it->second > max_token_value_) max_token_value_ = it->second;
        }

        if (explicit_n_vocab > 0) {
            if (mergeable_ranks.size() + special_tokens.size() != explicit_n_vocab) {
                throw std::invalid_argument("Vocabulary size mismatch");
            }
            if (max_token_value_ != explicit_n_vocab - 1) {
                throw std::invalid_argument("Max token value mismatch");
            }
        }

        core_bpe_ = std::make_shared<CoreBPE>(mergeable_ranks, special_tokens, pat_str);

        for (auto it = special_tokens.begin(); it != special_tokens.end(); ++it) {
            special_tokens_set_.insert(it->first);
        }
    }

    // ====================
    // Encoding
    // ====================

    std::vector<std::size_t> encode_ordinary(const std::string &text) const {
        return core_bpe_->encode_ordinary(text);
    }

    std::vector<std::size_t> encode(
        const std::string &text,
        const std::unordered_set<std::string> &allowed_special = std::unordered_set<std::string>(),
        bool disallow_all_special = true) const {

        std::unordered_set<std::string> effective_allowed = allowed_special;
        std::unordered_set<std::string> effective_disallowed;

        if (disallow_all_special && allowed_special.empty()) {
            effective_disallowed = special_tokens_set_;
        }

        if (!effective_disallowed.empty()) {
            for (auto it = effective_disallowed.begin(); it != effective_disallowed.end(); ++it) {
                if (text.find(*it) != std::string::npos) {
                    throw std::runtime_error(
                        "Encountered text corresponding to disallowed special token '" +
                        *it + "'. If you want this text to be encoded as a special token, "
                        "pass it to allowed_special. If you want this text to be encoded as "
                        "normal text, disable the check by passing disallowed_special=().");
                }
            }
        }

        return core_bpe_->encode(text, effective_allowed);
    }

    std::vector<std::vector<std::size_t>>
    encode_ordinary_batch(const std::vector<std::string> &texts,
                          int num_threads = 8) const {
        std::vector<std::vector<std::size_t>> results(texts.size());
        for (std::size_t i = 0; i < texts.size(); ++i) {
            results[i] = encode_ordinary(texts[i]);
        }
        return results;
    }

    std::vector<std::vector<std::size_t>>
    encode_batch(const std::vector<std::string> &texts,
                 const std::unordered_set<std::string> &allowed_special =
                     std::unordered_set<std::string>(),
                 int num_threads = 8) const {
        std::vector<std::vector<std::size_t>> results(texts.size());
        for (std::size_t i = 0; i < texts.size(); ++i) {
            results[i] = encode(texts[i], allowed_special, false);
        }
        return results;
    }

    std::pair<std::vector<std::size_t>, std::vector<std::vector<std::size_t>>>
    encode_with_unstable(
        const std::string &text,
        const std::unordered_set<std::string> &allowed_special = std::unordered_set<std::string>(),
        bool disallow_all_special = true) const {

        std::unordered_set<std::string> effective_allowed = allowed_special;
        std::unordered_set<std::string> effective_disallowed;

        if (disallow_all_special && allowed_special.empty()) {
            effective_disallowed = special_tokens_set_;
        }

        if (!effective_disallowed.empty()) {
            for (auto it = effective_disallowed.begin(); it != effective_disallowed.end(); ++it) {
                if (text.find(*it) != std::string::npos) {
                    throw std::runtime_error(
                        "Encountered text corresponding to disallowed special token '" + *it + "'.");
                }
            }
        }

        return core_bpe_->encode_with_unstable(text, effective_allowed);
    }

    std::size_t encode_single_token(const std::string &text) const {
        auto bytes = std::vector<uint8_t>(text.begin(), text.end());
        return core_bpe_->encode_single_token(bytes);
    }

    std::size_t encode_single_token_bytes(const std::vector<uint8_t> &bytes) const {
        return core_bpe_->encode_single_token(bytes);
    }

    // ====================
    // Decoding
    // ====================

    std::vector<uint8_t> decode_bytes(const std::vector<std::size_t> &tokens) const {
        return core_bpe_->decode_bytes(tokens);
    }

    std::string decode(const std::vector<std::size_t> &tokens,
                       const std::string &errors = "replace") const {
        auto bytes = core_bpe_->decode_bytes(tokens);
        return utf8_decode(bytes, errors);
    }

    std::vector<uint8_t> decode_single_token_bytes(std::size_t token) const {
        return core_bpe_->decode_single_token_bytes(token);
    }

    std::vector<std::vector<uint8_t>>
    decode_tokens_bytes(const std::vector<std::size_t> &tokens) const {
        std::vector<std::vector<uint8_t>> result;
        result.reserve(tokens.size());
        for (std::size_t i = 0; i < tokens.size(); ++i) {
            result.push_back(core_bpe_->decode_single_token_bytes(tokens[i]));
        }
        return result;
    }

    std::pair<std::string, std::vector<std::size_t>>
    decode_with_offsets(const std::vector<std::size_t> &tokens) const {
        auto token_bytes = decode_tokens_bytes(tokens);

        std::size_t text_len = 0;
        std::vector<std::size_t> offsets;
        offsets.reserve(tokens.size());

        for (std::size_t i = 0; i < token_bytes.size(); ++i) {
            const auto &token = token_bytes[i];
            if (!token.empty()) {
                std::size_t adjust = (0x80 <= token[0] && token[0] < 0xC0) ? 1 : 0;
                offsets.push_back(text_len > adjust ? text_len - adjust : 0);
                std::size_t char_count = 0;
                for (std::size_t j = 0; j < token.size(); ++j) {
                    if (!(0x80 <= token[j] && token[j] < 0xC0)) {
                        ++char_count;
                    }
                }
                text_len += char_count;
            } else {
                offsets.push_back(text_len);
            }
        }

        std::vector<uint8_t> all_bytes;
        for (std::size_t i = 0; i < token_bytes.size(); ++i) {
            all_bytes.insert(all_bytes.end(), token_bytes[i].begin(), token_bytes[i].end());
        }
        std::string text(all_bytes.begin(), all_bytes.end());

        return std::make_pair(text, offsets);
    }

    std::vector<std::string> decode_batch(const std::vector<std::vector<std::size_t>> &batch,
                                          const std::string &errors = "replace",
                                          int num_threads = 8) const {
        std::vector<std::string> results(batch.size());
        for (std::size_t i = 0; i < batch.size(); ++i) {
            results[i] = decode(batch[i], errors);
        }
        return results;
    }

    // ====================
    // Miscellaneous
    // ====================

    std::vector<std::vector<uint8_t>> token_byte_values() const {
        return core_bpe_->token_byte_values();
    }

    std::size_t eot_token() const {
        auto it = special_tokens_.find("");
        if (it == special_tokens_.end()) {
            throw std::runtime_error("No EOT token found");
        }
        return it->second;
    }

    const std::unordered_set<std::string> &special_tokens_set() const {
        return special_tokens_set_;
    }

    std::size_t n_vocab() const { return max_token_value_ + 1; }
    std::size_t max_token_value() const { return max_token_value_; }
    const std::string &name() const { return name_; }
    const std::string &pat_str() const { return pat_str_; }
    const Ranks &mergeable_ranks() const { return mergeable_ranks_; }
    const std::unordered_map<std::string, std::size_t> &special_tokens() const { return special_tokens_; }

    std::vector<std::size_t> _encode_single_piece(const std::vector<uint8_t> &piece) const {
        return core_bpe_->encode_single_piece(piece);
    }

    std::vector<std::size_t> _encode_bytes(const std::vector<uint8_t> &bytes) const {
        return core_bpe_->encode_bytes(bytes);
    }

  private:
    static std::string utf8_decode(const std::vector<uint8_t> &bytes,
                                   const std::string &errors) {
        std::string result;
        std::size_t i = 0;

        while (i < bytes.size()) {
            uint8_t b0 = bytes[i];
            std::size_t byte_count;
            uint32_t cp;

            if ((b0 & 0x80) == 0) {
                result += static_cast<char>(b0);
                ++i;
                continue;
            } else if ((b0 & 0xE0) == 0xC0) {
                byte_count = 2;
                cp = b0 & 0x1F;
            } else if ((b0 & 0xF0) == 0xE0) {
                byte_count = 3;
                cp = b0 & 0x0F;
            } else if ((b0 & 0xF8) == 0xF0) {
                byte_count = 4;
                cp = b0 & 0x07;
            } else {
                if (errors == "strict") throw std::runtime_error("Invalid UTF-8");
                else if (errors == "replace") result += "\xEF\xBF\xBD";
                ++i;
                continue;
            }

            if (i + byte_count > bytes.size()) {
                if (errors == "strict") throw std::runtime_error("Truncated UTF-8");
                else if (errors == "replace") result += "\xEF\xBF\xBD";
                break;
            }

            bool valid = true;
            for (std::size_t j = 1; j < byte_count; ++j) {
                if ((bytes[i + j] & 0xC0) != 0x80) {
                    valid = false;
                    break;
                }
                cp = (cp << 6) | (bytes[i + j] & 0x3F);
            }

            if (!valid) {
                if (errors == "strict") throw std::runtime_error("Invalid UTF-8 continuation");
                else if (errors == "replace") result += "\xEF\xBF\xBD";
                ++i;
                continue;
            }

            if (cp <= 0x7F) {
                result += static_cast<char>(cp);
            } else if (cp <= 0x7FF) {
                result += static_cast<char>(0xC0 | (cp >> 6));
                result += static_cast<char>(0x80 | (cp & 0x3F));
            } else if (cp <= 0xFFFF) {
                result += static_cast<char>(0xE0 | (cp >> 12));
                result += static_cast<char>(0x80 | ((cp >> 6) & 0x3F));
                result += static_cast<char>(0x80 | (cp & 0x3F));
            } else {
                result += static_cast<char>(0xF0 | (cp >> 18));
                result += static_cast<char>(0x80 | ((cp >> 12) & 0x3F));
                result += static_cast<char>(0x80 | ((cp >> 6) & 0x3F));
                result += static_cast<char>(0x80 | (cp & 0x3F));
            }

            i += byte_count;
        }

        return result;
    }

  private:
    std::string name_;
    std::string pat_str_;
    Ranks mergeable_ranks_;
    std::unordered_map<std::string, std::size_t> special_tokens_;
    std::size_t max_token_value_;
    std::size_t explicit_n_vocab_;
    std::shared_ptr<CoreBPE> core_bpe_;
    std::unordered_set<std::string> special_tokens_set_;
};

} // namespace tiktoken
