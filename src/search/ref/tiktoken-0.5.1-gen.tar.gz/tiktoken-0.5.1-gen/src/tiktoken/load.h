#pragma once

#include <cstdint>
#include <string>
#include <unordered_map>
#include <vector>

#include "bpe.h"

namespace tiktoken {

// Read file from local path (HTTP URLs not supported in this build)
std::vector<uint8_t> read_file(const std::string &blobpath);

// Read file with caching using SHA1 hash
std::vector<uint8_t> read_file_cached(const std::string &blobpath);

// Convert GPT-2 format to tiktoken format
Ranks data_gym_to_mergeable_bpe_ranks(const std::string &vocab_bpe_file,
                                       const std::string &encoder_json_file);

// Load tiktoken BPE format (base64 token + rank per line)
Ranks load_tiktoken_bpe(const std::string &tiktoken_bpe_file);

// Dump BPE ranks to file
void dump_tiktoken_bpe(const Ranks &bpe_ranks, const std::string &tiktoken_bpe_file);

} // namespace tiktoken
