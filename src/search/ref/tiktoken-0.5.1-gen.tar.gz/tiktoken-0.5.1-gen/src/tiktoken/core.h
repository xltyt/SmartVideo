#pragma once

#include "bpe.h"
#include "regex.h"

#include <cstdint>
#include <limits>
#include <mutex>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <utility>
#include <vector>

namespace tiktoken {

class CoreBPE {
  public:
    CoreBPE(const Ranks &encoder,
            const std::unordered_map<std::string, std::size_t> &special_tokens_encoder,
            const std::string &pattern);

    // ====================
    // Encoding
    // ====================

    std::vector<std::size_t> encode_ordinary(const std::string &text) const;

    std::vector<std::size_t> encode(const std::string &text,
                                    const std::unordered_set<std::string> &allowed_special) const;

    std::pair<std::vector<std::size_t>, std::vector<std::vector<std::size_t>>>
    encode_with_unstable(const std::string &text,
                         const std::unordered_set<std::string> &allowed_special) const;

    std::size_t encode_single_token(const std::vector<uint8_t> &piece) const;

    std::vector<std::size_t> encode_single_piece(const std::vector<uint8_t> &piece) const;

    std::vector<std::size_t> encode_bytes(const std::vector<uint8_t> &bytes) const;

    // ====================
    // Decoding
    // ====================

    std::vector<uint8_t> decode_bytes(const std::vector<std::size_t> &tokens) const;

    std::vector<uint8_t> decode_single_token_bytes(std::size_t token) const;

    // ====================
    // Miscellaneous
    // ====================

    std::vector<std::vector<uint8_t>> token_byte_values() const;

  private:
    std::vector<std::size_t> _encode_ordinary_native(const std::string &text) const;
    std::pair<std::vector<std::size_t>, std::size_t>
    _encode_native(const std::string &text,
                   const std::unordered_set<std::string> &allowed_special) const;

    std::vector<uint8_t> _decode_native(const std::vector<std::size_t> &tokens) const;

    std::pair<std::vector<std::size_t>, std::size_t>
    _increase_last_piece_token_len(std::vector<std::size_t> tokens,
                                   std::size_t last_piece_token_len) const;

  private:
    Ranks encoder_;
    std::unordered_map<std::string, std::size_t> special_tokens_encoder_;
    std::unordered_map<std::size_t, std::vector<uint8_t>> decoder_;
    std::unordered_map<std::size_t, std::vector<uint8_t>> special_tokens_decoder_;
    Regex regex_;
    Regex special_regex_;
    std::vector<std::vector<uint8_t>> sorted_token_bytes_;
};

} // namespace tiktoken
