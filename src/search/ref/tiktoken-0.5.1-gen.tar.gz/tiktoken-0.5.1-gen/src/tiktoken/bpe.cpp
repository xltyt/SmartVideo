#include "bpe.h"

#include <algorithm>
#include <vector>

namespace tiktoken {

namespace detail {
template <typename T>
class Opt {
  public:
    Opt() : has_(false) {}
    Opt(const T &v) : has_(true), val_(v) {}
    Opt &operator=(const T &v) { has_ = true; val_ = v; return *this; }
    bool has_value() const { return has_; }
    const T &value() const { return val_; }
    T value_or(const T &default_val) const { return has_ ? val_ : default_val; }
  private:
    bool has_;
    T val_;
};
} // namespace detail

std::vector<std::pair<std::size_t, std::size_t>>
_byte_pair_merge_parts(const std::vector<uint8_t> &piece, const Ranks &ranks) {

    std::vector<std::pair<std::size_t, std::size_t>> parts;
    parts.reserve(piece.size() + 1);
    for (std::size_t i = 0; i <= piece.size(); ++i) {
        parts.emplace_back(i, std::numeric_limits<std::size_t>::max());
    }

    auto get_rank = [&](std::size_t start_idx, std::size_t skip) -> detail::Opt<std::size_t> {
        if ((start_idx + skip + 2) < parts.size()) {
            std::vector<uint8_t> key(
                piece.begin() + parts[start_idx].first,
                piece.begin() + parts[start_idx + skip + 2].first);
            auto it = ranks.find(key);
            if (it != ranks.end()) {
                return it->second;
            }
        }
        return detail::Opt<std::size_t>();
    };

    for (std::size_t i = 0; i + 2 < parts.size(); ++i) {
        auto rank = get_rank(i, 0);
        if (rank.has_value()) {
            parts[i].second = rank.value();
        }
    }

    while (parts.size() > 1) {
        std::size_t min_rank = std::numeric_limits<std::size_t>::max();
        std::size_t min_idx = 0;
        for (std::size_t i = 0; i + 1 < parts.size(); ++i) {
            if (parts[i].second < min_rank) {
                min_rank = parts[i].second;
                min_idx = i;
            }
        }

        if (min_rank == std::numeric_limits<std::size_t>::max()) {
            break;
        }

        if (min_idx > 0) {
            auto r = get_rank(min_idx - 1, 1);
            parts[min_idx - 1].second = r.value_or(std::numeric_limits<std::size_t>::max());
        }

        auto r2 = get_rank(min_idx, 1);
        parts[min_idx].second = r2.value_or(std::numeric_limits<std::size_t>::max());

        parts.erase(parts.begin() + static_cast<std::ptrdiff_t>(min_idx + 1));
    }

    std::vector<std::pair<std::size_t, std::size_t>> result;
    result.reserve(parts.size() > 0 ? parts.size() - 1 : 0);
    for (std::size_t i = 0; i + 1 < parts.size(); ++i) {
        result.emplace_back(parts[i].first, parts[i + 1].first);
    }
    return result;
}

std::vector<std::size_t> byte_pair_encode(const std::vector<uint8_t> &piece,
                                          const Ranks &ranks) {
    if (piece.size() == 1) {
        auto it = ranks.find(piece);
        if (it != ranks.end()) {
            return {it->second};
        }
        return {};
    }

    auto parts = _byte_pair_merge_parts(piece, ranks);
    std::vector<std::size_t> result;
    result.reserve(parts.size());
    for (const auto &p : parts) {
        std::vector<uint8_t> key(piece.begin() + p.first, piece.begin() + p.second);
        auto it = ranks.find(key);
        if (it != ranks.end()) {
            result.push_back(it->second);
        } else {
            // This should not happen
            result.push_back(0);
        }
    }
    return result;
}

std::vector<std::vector<uint8_t>>
byte_pair_split(const std::vector<uint8_t> &piece, const Ranks &ranks) {
    if (piece.size() == 1) {
        return {piece};
    }

    auto parts = _byte_pair_merge_parts(piece, ranks);
    std::vector<std::vector<uint8_t>> result;
    result.reserve(parts.size());
    for (const auto &p : parts) {
        result.emplace_back(piece.begin() + p.first, piece.begin() + p.second);
    }
    return result;
}

} // namespace tiktoken
