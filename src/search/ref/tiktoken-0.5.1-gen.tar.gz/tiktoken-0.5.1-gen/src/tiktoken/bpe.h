#pragma once

#include <cstdint>
#include <functional>
#include <limits>
#include <unordered_map>
#include <vector>

namespace tiktoken {

struct VecByteHash {
    std::size_t operator()(const std::vector<uint8_t> &v) const noexcept {
        std::size_t h = 0x811c9dc5;
        for (std::size_t i = 0; i < v.size(); ++i) {
            h ^= static_cast<std::size_t>(v[i]);
            h *= 0x01000193;
        }
        return h;
    }
};

struct VecByteEq {
    bool operator()(const std::vector<uint8_t> &a,
                    const std::vector<uint8_t> &b) const noexcept {
        return a == b;
    }
};

using Ranks = std::unordered_map<std::vector<uint8_t>, std::size_t, VecByteHash, VecByteEq>;

// Core BPE merge algorithm - returns a vector of (start, end) pairs
std::vector<std::pair<std::size_t, std::size_t>>
_byte_pair_merge_parts(const std::vector<uint8_t> &piece, const Ranks &ranks);

// Encode a byte piece into token IDs using BPE
std::vector<std::size_t> byte_pair_encode(const std::vector<uint8_t> &piece,
                                           const Ranks &ranks);

// Split a byte piece into segments at BPE merge boundaries
std::vector<std::vector<uint8_t>>
byte_pair_split(const std::vector<uint8_t> &piece, const Ranks &ranks);

} // namespace tiktoken
