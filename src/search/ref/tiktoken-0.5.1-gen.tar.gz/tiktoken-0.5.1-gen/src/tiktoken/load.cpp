#include "load.h"

#include <algorithm>
#include <cassert>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <stdexcept>

#include <openssl/sha.h>

namespace tiktoken {

namespace {

std::string sha1_hex(const std::string &input) {
    unsigned char hash[SHA_DIGEST_LENGTH];
    SHA1(reinterpret_cast<const unsigned char *>(input.c_str()), input.size(), hash);

    std::ostringstream ss;
    for (int i = 0; i < SHA_DIGEST_LENGTH; ++i) {
        ss << std::hex << std::setfill('0') << std::setw(2) << static_cast<int>(hash[i]);
    }
    return ss.str();
}

std::vector<uint8_t> base64_decode(const std::string &encoded) {
    static const std::string base64_chars =
        "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
        "abcdefghijklmnopqrstuvwxyz"
        "0123456789+/";

    int T[256];
    std::memset(T, -1, sizeof(T));
    for (int i = 0; i < 64; i++) {
        T[static_cast<unsigned char>(base64_chars[i])] = i;
    }

    std::vector<uint8_t> result;
    result.reserve(encoded.size() * 3 / 4);

    int val = 0, valb = -8;
    for (std::size_t i = 0; i < encoded.size(); ++i) {
        unsigned char c = static_cast<unsigned char>(encoded[i]);
        if (T[c] == -1) break;
        val = (val << 6) + T[c];
        valb += 6;
        if (valb >= 0) {
            result.push_back(static_cast<uint8_t>((val >> valb) & 0xFF));
            valb -= 8;
        }
    }
    return result;
}

std::string base64_encode(const std::vector<uint8_t> &data) {
    static const std::string base64_chars =
        "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
        "abcdefghijklmnopqrstuvwxyz"
        "0123456789+/";

    std::string result;
    result.reserve(((data.size() + 2) / 3) * 4);

    int i = 0;
    unsigned char arr3[3];
    unsigned char arr4[4];

    for (std::size_t idx = 0; idx < data.size(); ++idx) {
        arr3[i++] = data[idx];
        if (i == 3) {
            arr4[0] = (arr3[0] & 0xfc) >> 2;
            arr4[1] = ((arr3[0] & 0x03) << 4) + ((arr3[1] & 0xf0) >> 4);
            arr4[2] = ((arr3[1] & 0x0f) << 2) + ((arr3[2] & 0xc0) >> 6);
            arr4[3] = arr3[2] & 0x3f;

            for (int j = 0; j < 4; j++) {
                result += base64_chars[arr4[j]];
            }
            i = 0;
        }
    }

    if (i) {
        for (int j = i; j < 3; j++) {
            arr3[j] = '\0';
        }

        arr4[0] = (arr3[0] & 0xfc) >> 2;
        arr4[1] = ((arr3[0] & 0x03) << 4) + ((arr3[1] & 0xf0) >> 4);
        arr4[2] = ((arr3[1] & 0x0f) << 2) + ((arr3[2] & 0xc0) >> 6);
        arr4[3] = arr3[2] & 0x3f;

        for (int j = 0; j < i + 1; j++) {
            result += base64_chars[arr4[j]];
        }
        while (i++ < 3) {
            result += '=';
        }
    }

    return result;
}

// Call Python to download a file (fallback when libcurl is not available)
std::vector<uint8_t> http_get_python(const std::string &url) {
    std::string cmd = "python3 -c \"import requests; import sys; "
                      "r = requests.get('" + url + "'); "
                      "r.raise_for_status(); "
                      "sys.stdout.buffer.write(r.content)\"";

    // Use popen to capture output
    FILE *pipe = popen(cmd.c_str(), "r");
    if (!pipe) {
        throw std::runtime_error("Failed to execute Python for HTTP request: " + url);
    }

    std::vector<uint8_t> buf;
    char tmp[4096];
    while (true) {
        std::size_t n = std::fread(tmp, 1, sizeof(tmp), pipe);
        if (n == 0) break;
        buf.insert(buf.end(), tmp, tmp + n);
    }

    int status = pclose(pipe);
    if (status != 0) {
        throw std::runtime_error("Python HTTP request failed for: " + url);
    }

    return buf;
}

} // namespace

std::vector<uint8_t> read_file(const std::string &blobpath) {
    // HTTP URL - use Python requests as fallback
    if (blobpath.compare(0, 7, "http://") == 0 ||
        blobpath.compare(0, 8, "https://") == 0) {
        return http_get_python(blobpath);
    }

    // Local file
    std::ifstream file(blobpath, std::ios::binary);
    if (!file) {
        throw std::runtime_error("Cannot open file: " + blobpath);
    }
    return std::vector<uint8_t>((std::istreambuf_iterator<char>(file)),
                                std::istreambuf_iterator<char>());
}

std::vector<uint8_t> read_file_cached(const std::string &blobpath) {
    std::string cache_dir;

    const char *tiktoken_cache = std::getenv("TIKTOKEN_CACHE_DIR");
    const char *data_gym_cache = std::getenv("DATA_GYM_CACHE_DIR");

    if (tiktoken_cache) {
        cache_dir = tiktoken_cache;
    } else if (data_gym_cache) {
        cache_dir = data_gym_cache;
    } else {
        cache_dir = "/tmp/data-gym-cache";
    }

    if (cache_dir.empty()) {
        return read_file(blobpath);
    }

    std::string cache_key = sha1_hex(blobpath);
    std::string cache_path = cache_dir + "/" + cache_key;

    // Check cache
    {
        std::ifstream file(cache_path, std::ios::binary);
        if (file) {
            return std::vector<uint8_t>((std::istreambuf_iterator<char>(file)),
                                        std::istreambuf_iterator<char>());
        }
    }

    // Download and cache
    auto contents = read_file(blobpath);

    // Create cache directory
    std::string mkdir_cmd = "mkdir -p " + cache_dir;
    std::system(mkdir_cmd.c_str());

    // Write to temp file then rename (atomic)
    std::string tmp_path = cache_path + ".tmp";
    {
        std::ofstream file(tmp_path, std::ios::binary);
        if (file) {
            file.write(reinterpret_cast<const char *>(contents.data()), contents.size());
        }
    }

    std::rename(tmp_path.c_str(), cache_path.c_str());

    return contents;
}

Ranks load_tiktoken_bpe(const std::string &tiktoken_bpe_file) {
    auto contents = read_file_cached(tiktoken_bpe_file);

    Ranks ranks;

    std::string content_str(contents.begin(), contents.end());
    std::istringstream stream(content_str);
    std::string line;

    while (std::getline(stream, line)) {
        if (line.empty()) continue;

        auto space_pos = line.find(' ');
        if (space_pos == std::string::npos) continue;

        std::string token_b64 = line.substr(0, space_pos);
        std::string rank_str = line.substr(space_pos + 1);

        auto token_bytes = base64_decode(token_b64);
        std::size_t rank = std::stoull(rank_str);
        ranks[token_bytes] = rank;
    }

    return ranks;
}

// Simple JSON parser for encoder.json (only handles flat string:int maps)
namespace {
    // Minimal JSON parsing for the encoder.json format
    // Format: {"key1": value1, "key2": value2, ...}
    std::vector<std::pair<std::string, std::size_t>>
    parse_encoder_json(const std::string &json_str) {
        std::vector<std::pair<std::string, std::size_t>> result;

        std::size_t i = 0;
        // Skip whitespace
        while (i < json_str.size() && std::isspace(json_str[i])) ++i;

        if (i >= json_str.size() || json_str[i] != '{') return result;
        ++i; // skip {

        while (i < json_str.size()) {
            // Skip whitespace
            while (i < json_str.size() && std::isspace(json_str[i])) ++i;
            if (i >= json_str.size() || json_str[i] == '}') break;

            // Parse key (string)
            if (json_str[i] != '"') break;
            ++i; // skip opening "
            std::string key;
            while (i < json_str.size() && json_str[i] != '"') {
                if (json_str[i] == '\\' && i + 1 < json_str.size()) {
                    ++i; // skip escape char
                    if (json_str[i] == 'n') { key += '\n'; }
                    else if (json_str[i] == 't') { key += '\t'; }
                    else if (json_str[i] == 'r') { key += '\r'; }
                    else if (json_str[i] == '\\') { key += '\\'; }
                    else if (json_str[i] == '"') { key += '"'; }
                    else if (json_str[i] == '/') { key += '/'; }
                    else if (json_str[i] == 'u') {
                        // Unicode escape \uXXXX - simplified: just skip 4 hex digits
                        if (i + 4 < json_str.size()) {
                            unsigned int codepoint;
                            std::stringstream ss;
                            ss << std::hex << json_str.substr(i + 1, 4);
                            ss >> codepoint;
                            i += 4;
                            // Encode as UTF-8
                            if (codepoint <= 0x7F) {
                                key += static_cast<char>(codepoint);
                            } else if (codepoint <= 0x7FF) {
                                key += static_cast<char>(0xC0 | (codepoint >> 6));
                                key += static_cast<char>(0x80 | (codepoint & 0x3F));
                            } else {
                                key += static_cast<char>(0xE0 | (codepoint >> 12));
                                key += static_cast<char>(0x80 | ((codepoint >> 6) & 0x3F));
                                key += static_cast<char>(0x80 | (codepoint & 0x3F));
                            }
                        }
                    } else {
                        key += json_str[i];
                    }
                } else {
                    key += json_str[i];
                }
                ++i;
            }
            if (i < json_str.size()) ++i; // skip closing "

            // Skip whitespace and colon
            while (i < json_str.size() && (std::isspace(json_str[i]) || json_str[i] == ':')) ++i;

            // Parse value (integer)
            std::string val_str;
            while (i < json_str.size() && json_str[i] != ',' && json_str[i] != '}' &&
                   !std::isspace(json_str[i])) {
                val_str += json_str[i];
                ++i;
            }
            std::size_t value = 0;
            if (!val_str.empty()) {
                value = std::stoull(val_str);
            }

            result.push_back(std::make_pair(key, value));

            // Skip whitespace and comma
            while (i < json_str.size() && (std::isspace(json_str[i]) || json_str[i] == ',')) ++i;
        }

        return result;
    }
} // namespace

Ranks data_gym_to_mergeable_bpe_ranks(const std::string &vocab_bpe_file,
                                       const std::string &encoder_json_file) {
    // Build the byte-to-byte mapping used by GPT-2
    std::vector<uint8_t> rank_to_intbyte;
    for (int b = 0; b < 256; ++b) {
        if (std::isprint(b) && b != ' ') {
            rank_to_intbyte.push_back(static_cast<uint8_t>(b));
        }
    }

    std::unordered_map<uint8_t, uint8_t> data_gym_byte_to_byte;
    for (std::size_t i = 0; i < rank_to_intbyte.size(); ++i) {
        data_gym_byte_to_byte[rank_to_intbyte[i]] = rank_to_intbyte[i];
    }

    int n = 0;
    for (int b = 0; b < 256; ++b) {
        if (std::find(rank_to_intbyte.begin(), rank_to_intbyte.end(),
                      static_cast<uint8_t>(b)) == rank_to_intbyte.end()) {
            rank_to_intbyte.push_back(static_cast<uint8_t>(b));
            data_gym_byte_to_byte[static_cast<uint8_t>(256 + n)] = static_cast<uint8_t>(b);
            n++;
        }
    }

    // Parse vocab.bpe
    auto vocab_contents = read_file_cached(vocab_bpe_file);
    std::string vocab_str(vocab_contents.begin(), vocab_contents.end());

    std::vector<std::pair<std::string, std::string>> bpe_merges;
    std::istringstream vocab_stream(vocab_str);
    std::string line;
    std::getline(vocab_stream, line); // Skip first line

    while (std::getline(vocab_stream, line)) {
        if (line.empty()) continue;
        auto space_pos = line.find(' ');
        if (space_pos == std::string::npos) continue;
        bpe_merges.push_back(
            std::make_pair(line.substr(0, space_pos), line.substr(space_pos + 1)));
    }

    auto decode_data_gym = [&](const std::string &value) -> std::vector<uint8_t> {
        std::vector<uint8_t> result;
        result.reserve(value.size());
        for (std::size_t i = 0; i < value.size(); ++i) {
            unsigned char c = static_cast<unsigned char>(value[i]);
            auto it = data_gym_byte_to_byte.find(c);
            if (it != data_gym_byte_to_byte.end()) {
                result.push_back(it->second);
            }
        }
        return result;
    };

    // Add single byte tokens
    Ranks bpe_ranks;
    for (std::size_t i = 0; i < rank_to_intbyte.size(); ++i) {
        bpe_ranks[{rank_to_intbyte[i]}] = i;
    }

    // Add merged tokens
    std::size_t rank_count = bpe_ranks.size();
    for (std::size_t mi = 0; mi < bpe_merges.size(); ++mi) {
        auto decoded = decode_data_gym(bpe_merges[mi].first);
        auto decoded_second = decode_data_gym(bpe_merges[mi].second);
        decoded.insert(decoded.end(), decoded_second.begin(), decoded_second.end());
        bpe_ranks[decoded] = rank_count++;
    }

    // Verify against encoder.json
    auto encoder_contents = read_file_cached(encoder_json_file);
    std::string encoder_str(encoder_contents.begin(), encoder_contents.end());
    auto json_entries = parse_encoder_json(encoder_str);

    Ranks encoder_json_loaded;
    for (std::size_t i = 0; i < json_entries.size(); ++i) {
        auto decoded_key = decode_data_gym(json_entries[i].first);
        encoder_json_loaded[decoded_key] = json_entries[i].second;
    }

    // Remove special tokens
    std::vector<uint8_t> endoftext_key = decode_data_gym("");
    std::vector<uint8_t> startoftext_key = decode_data_gym("<|startoftext|>");
    encoder_json_loaded.erase(endoftext_key);
    encoder_json_loaded.erase(startoftext_key);

    // Verify consistency
    if (bpe_ranks != encoder_json_loaded) {
        // Not throwing - just log warning as there can be minor differences
        std::cerr << "Warning: BPE ranks do not exactly match encoder.json" << std::endl;
    }

    return bpe_ranks;
}

void dump_tiktoken_bpe(const Ranks &bpe_ranks, const std::string &tiktoken_bpe_file) {
    std::vector<std::pair<std::vector<uint8_t>, std::size_t>> sorted_ranks(
        bpe_ranks.begin(), bpe_ranks.end());
    std::sort(sorted_ranks.begin(), sorted_ranks.end(),
              [](const std::pair<std::vector<uint8_t>, std::size_t> &a,
                 const std::pair<std::vector<uint8_t>, std::size_t> &b) {
                  return a.second < b.second;
              });

    std::ofstream file(tiktoken_bpe_file, std::ios::binary);
    if (!file) {
        throw std::runtime_error("Cannot write to file: " + tiktoken_bpe_file);
    }

    for (std::size_t i = 0; i < sorted_ranks.size(); ++i) {
        file << base64_encode(sorted_ranks[i].first) << " " << sorted_ranks[i].second << "\n";
    }
}

} // namespace tiktoken
