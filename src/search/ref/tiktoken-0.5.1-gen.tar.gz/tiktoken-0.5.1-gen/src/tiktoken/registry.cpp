#include "registry.h"
#include "load.h"
#include "tiktoken.h"

#include <mutex>
#include <unordered_map>

namespace tiktoken {

namespace {

const std::string ENDOFTEXT = "";
const std::string FIM_PREFIX = "<|fim_prefix|>";
const std::string FIM_MIDDLE = "<|fim_middle|>";
const std::string FIM_SUFFIX = "<|fim_suffix|>";
const std::string ENDOFPROMPT = "<|endofprompt|>";

Encoding make_gpt2() {
    auto mergeable_ranks = data_gym_to_mergeable_bpe_ranks(
        "https://openaipublic.blob.core.windows.net/gpt-2/encodings/main/vocab.bpe",
        "https://openaipublic.blob.core.windows.net/gpt-2/encodings/main/encoder.json");

    std::unordered_map<std::string, std::size_t> special_tokens;
    special_tokens[ENDOFTEXT] = 50256;

    return Encoding(
        "gpt2",
        "'s|'t|'re|'ve|'m|'ll|'d| ?\\p{L}+| ?\\p{N}+| ?[^\\s\\p{L}\\p{N}]+|\\s+(?!\\S)|\\s+",
        mergeable_ranks,
        special_tokens,
        50257);
}

Encoding make_r50k_base() {
    auto mergeable_ranks = load_tiktoken_bpe(
        "https://openaipublic.blob.core.windows.net/encodings/r50k_base.tiktoken");

    std::unordered_map<std::string, std::size_t> special_tokens;
    special_tokens[ENDOFTEXT] = 50256;

    return Encoding(
        "r50k_base",
        "'s|'t|'re|'ve|'m|'ll|'d| ?\\p{L}+| ?\\p{N}+| ?[^\\s\\p{L}\\p{N}]+|\\s+(?!\\S)|\\s+",
        mergeable_ranks,
        special_tokens,
        50257);
}

Encoding make_p50k_base() {
    auto mergeable_ranks = load_tiktoken_bpe(
        "https://openaipublic.blob.core.windows.net/encodings/p50k_base.tiktoken");

    std::unordered_map<std::string, std::size_t> special_tokens;
    special_tokens[ENDOFTEXT] = 50256;

    return Encoding(
        "p50k_base",
        "'s|'t|'re|'ve|'m|'ll|'d| ?\\p{L}+| ?\\p{N}+| ?[^\\s\\p{L}\\p{N}]+|\\s+(?!\\S)|\\s+",
        mergeable_ranks,
        special_tokens,
        50281);
}

Encoding make_p50k_edit() {
    auto mergeable_ranks = load_tiktoken_bpe(
        "https://openaipublic.blob.core.windows.net/encodings/p50k_base.tiktoken");

    std::unordered_map<std::string, std::size_t> special_tokens;
    special_tokens[ENDOFTEXT] = 50256;
    special_tokens[FIM_PREFIX] = 50281;
    special_tokens[FIM_MIDDLE] = 50282;
    special_tokens[FIM_SUFFIX] = 50283;

    return Encoding(
        "p50k_edit",
        "'s|'t|'re|'ve|'m|'ll|'d| ?\\p{L}+| ?\\p{N}+| ?[^\\s\\p{L}\\p{N}]+|\\s+(?!\\S)|\\s+",
        mergeable_ranks,
        special_tokens);
}

Encoding make_cl100k_base() {
    auto mergeable_ranks = load_tiktoken_bpe(
        "https://openaipublic.blob.core.windows.net/encodings/cl100k_base.tiktoken");

    std::unordered_map<std::string, std::size_t> special_tokens;
    special_tokens[ENDOFTEXT] = 100257;
    special_tokens[FIM_PREFIX] = 100258;
    special_tokens[FIM_MIDDLE] = 100259;
    special_tokens[FIM_SUFFIX] = 100260;
    special_tokens[ENDOFPROMPT] = 100276;

    return Encoding(
        "cl100k_base",
        "(?i:'s|'t|'re|'ve|'m|'ll|'d)|[^\\r\\n\\p{L}\\p{N}]?\\p{L}+|\\p{N}{1,3}| ?[^\\s\\p{L}\\p{N}]+[\\r\\n]*|\\s*[\\r\\n]+|\\s+(?!\\S)|\\s+",
        mergeable_ranks,
        special_tokens);
}

struct Registry {
    std::unordered_map<std::string, EncodingConstructor> constructors;
    std::unordered_map<std::string, Encoding> encodings;
    std::mutex mutex;

    Registry() {
        constructors["gpt2"] = make_gpt2;
        constructors["r50k_base"] = make_r50k_base;
        constructors["p50k_base"] = make_p50k_base;
        constructors["p50k_edit"] = make_p50k_edit;
        constructors["cl100k_base"] = make_cl100k_base;
    }
};

Registry &get_registry() {
    static Registry reg;
    return reg;
}

} // namespace

Encoding get_encoding(const std::string &encoding_name) {
    auto &reg = get_registry();

    {
        std::lock_guard<std::mutex> lock(reg.mutex);
        auto it = reg.encodings.find(encoding_name);
        if (it != reg.encodings.end()) {
            return it->second;
        }
    }

    auto ctor_it = reg.constructors.find(encoding_name);
    if (ctor_it == reg.constructors.end()) {
        throw std::runtime_error("Unknown encoding: " + encoding_name);
    }

    Encoding enc = ctor_it->second();

    {
        std::lock_guard<std::mutex> lock(reg.mutex);
        reg.encodings.insert(std::make_pair(encoding_name, enc));
    }

    return enc;
}

std::vector<std::string> list_encoding_names() {
    auto &reg = get_registry();
    std::vector<std::string> names;
    for (auto it = reg.constructors.begin(); it != reg.constructors.end(); ++it) {
        names.push_back(it->first);
    }
    return names;
}

} // namespace tiktoken
